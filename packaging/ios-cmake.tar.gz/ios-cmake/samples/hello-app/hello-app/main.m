//
//  main.m
//  hello-app
//
//  Created by Bogdan Cristea on 12/27/13.
//  Copyright (c) 2013 Bogdan Cristea. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CRAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CRAppDelegate class]));
    }
}
