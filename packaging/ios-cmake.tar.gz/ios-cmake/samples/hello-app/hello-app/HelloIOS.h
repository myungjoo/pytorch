#import <Foundation/Foundation.h>

@interface HelloIOS : NSObject

- (NSString*)getHello;

@end
