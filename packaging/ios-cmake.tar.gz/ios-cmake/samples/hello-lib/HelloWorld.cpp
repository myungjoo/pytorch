#include "HelloWorld.h"

std::string HelloWorld::helloWorld()
{
	return std::string("Hello World");
}
