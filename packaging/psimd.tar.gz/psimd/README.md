# P(ortable) SIMD
Portable 128-bit SIMD intrinsics
