#!/bin/bash
set -ev
brew update
