# List of contributors


| Name                 | Affiliation             | Github profile                     |
| -------------------- | ----------------------- | ---------------------------------- |
| Naoki Shibata        | Nara Institute of Science and Technology | https://github.com/shibatch |
| Jilayne Lovejoy      | Arm Inc.                | https://github.com/jlovejoy        |
| Francesco Petrogalli | Arm Ltd.                | https://github.com/fpetrogalli-arm |
| Diana Bite           | Arm Ltd.                | https://github.com/diaena          |
| Alexandre Mutel      | Unity Technologies      | https://github.com/xoofx           |
| Martin Krastev       | Chaos Group             | https://github.com/blu             |
