#!/bin/bash

source /opt/intel/bin/compilervars.sh intel64
